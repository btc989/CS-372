var city_states = Object();

city_states["Alberta"] = "|Calgary|Edmonton|Medicine Hat";
city_states["British Columbia"] = "|Abbotsford|Burnaby|Coquitlam|Kelowna|Langley|North Vancouver |Richmond|Surrey|Vancouver";
city_states["Manitoba"] = "|Brandon|Steinbach|Thompson|Winnipeg";
city_states["New Brunswick"] = "|Dieppe|Fredericton|Moncton|Saint John";
city_states["Newfoundland/Labrador"] = "|Corner Brook|Conception Bay South|Mount Pearl|Paradise|St.John's";
city_states["Nova Scotia  "] = "|Amherst|Cape Breton|Halifax|Turo";
city_states["Northwest Territories"] = "|Inuvik|Yellowknife";
city_states["Nunavut"] = "|Iqaluit";
city_states["Ontario"] = "|Brampton|Hamilton|London|Mississauga|Ottawa|Toronto";
city_states["Prince Edward Island"] = "|Charlottetown|Summerside";
city_states["Quebec"] = "|Gatineua|Laval|Longueuil|Quebec|Montreal";
city_states["Saskatchewan"] = "|Moose Jaw|Regina|Saskatoon";
city_states["Yukon"] = "|Whitehorse";


function logIn(event)
{
    var test=true;
    //*****Email **************//
    
      var email = document.getElementById("email").value;
      var emailpat = /^(([a-zA-Z]|[0-9])|([-]|[_]|[.]))+[@](([a-zA-Z0-9])|([-])){2,63}[.](([a-zA-Z0-9]){2,63})+$/;
     if (email === "" || email.length === 0) //checks if empty
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        event.preventDefault();  
        test= false;
    }
    else
    {
        document.getElementById("email").className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-email").innerHTML = "";
        document.getElementById("label-email").style.color = "#000";
    }
    
    if(!email.match(emailpat))
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        document.getElementById("invalid-email").innerHTML = "Please enter valid email (example@example.com/ca)";
        event.preventDefault();  
        test= false;
    }
    if(email.length>256)
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        document.getElementById("invalid-email").innerHTML = "Email address is too long)";
        event.preventDefault();  
        test= false;
    }
    var password = document.getElementById("password").value;
      if (password === "" || password.length === 0) //checks if empty
        {
            document.getElementById("password").className="errorBorder";  //add red borders-and text
            document.getElementById("invalid-password").innerHTML = "Please enter your password";
            event.preventDefault();  
            test=false;
        }
    
}
function createAccount(event)
{
    var test=true;
    //*****First Name **************//
    
    var first = document.getElementById("firstName").value;
    
     if (first === "" || first.length === 0) //checks if empty
    {
        document.getElementById("firstName").className="errorBorder";  //add red borders-and text
        document.getElementById("label-firstName").style.color = "red";
        event.preventDefault();  
        test=false;
    }
    else if(first.length <2)
    {                       
        document.getElementById("firstName").className="errorBorder";  //add red borders-and text
        document.getElementById("label-firstName").style.color = "red";
        document.getElementById("invalid-firstName").innerHTML = "Longer then 2 characters";
        event.preventDefault(); 
        test=false;
    }
    else if(first.length >50)
    {
        document.getElementById("firstName").className="errorBorder";  //add red borders-and text
        document.getElementById("label-firstName").style.color = "red";
        document.getElementById("invalid-firstName").innerHTML = "Can not be greater then 50 characters";
        event.preventDefault();
        test=false;
    }
    else
    {
        document.getElementById("firstName").className =("sminput");  //if fixed applies old style
        document.getElementById("invalid-firstName").innerHTML = "";   
        document.getElementById("label-firstName").style.color = "#000";
    }
    
    //*****Last Name **************//
     var last = document.getElementById("lastName").value;

     if (last === "" || last.length === 0) //checks if empty
    {
        document.getElementById("lastName").className="errorBorder";  //add red borders-and text
         document.getElementById("label-lastName").style.color = "red";
        event.preventDefault();  
        test=false;
    }
    else if(first.length <2)
    {
        document.getElementById("lastName").className="errorBorder";  //add red borders-and text
        document.getElementById("label-lastName").style.color = "red";
        document.getElementById("invalid-lastName").innerHTML = "Longer then 2 characters";
        event.preventDefault(); 
        test=false;
    }
    else if(first.length >50)
    {
        document.getElementById("lastName").className="errorBorder";  //add red borders-and text
        document.getElementById("label-lastName").style.color = "red";
        document.getElementById("invalid-lastname").innerHTML = "Can not be greater then 50 characters";
        event.preventDefault();
        test=false;
    }
    else
    {
        document.getElementById("lastName").className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-lastName").innerHTML = "";    
        document.getElementById("label-lastName").style.color = "#000";
    }
    //*****Birthdate **************//
    var month = document.getElementById("month").value;
    var day = document.getElementById("day").value;
    var year = document.getElementById("year").value;
    
    var daypat =/(?:(?:0[1-9])|(?:[12][0-9])|(?:3[01]))/;
    var monthpat =/(?:(?:0[1-9])|(?:[1][0-2]))/;
    var yearpat =/^\d{4}$/;
    var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31]; 
    if (month === "00" || day==="00" || year==="00") //checks if empty
    {
        document.getElementById("month").className="errorborder2";  //add red borders-and text
        document.getElementById("day").className="errorborder2";  //add red borders-and text
        document.getElementById("year").className="errorborder2";  //add red borders-and text
        document.getElementById("invalid-month").innerHTML = "Please enter your birth date";
        event.preventDefault();  
        test=false;
    }
    else
    {
        if(month.match(monthpat) && day.match(daypat) && year.match(yearpat))
        {
                if (month===01 || month>02)  
                {  
                    if (day>ListofDays[month-1])  
                    {  
                        document.getElementById("month").className="errorborder2";  //add red borders-and text
                        document.getElementById("day").className="errorborder2";  //add red borders-and text
                        document.getElementById("year").className="errorborder2";  //add red borders-and text
                        document.getElementById("invalid-month").innerHTML = "Invalid Date";  
                        test= false;  
                    }  
                }  
                if (month==="02")  
                {  
                    var lyear = false;  
                    if ( (!(year % 4) && year % 100) || !(year % 400))   
                    {  
                        lyear = true;  
                    }  
                    if ((lyear===false) && (day>=29))  
                    {  
                        document.getElementById("month").className="errorborder2";  //add red borders-and text
                        document.getElementById("day").className="errorborder2";  //add red borders-and text
                        document.getElementById("year").className="errorborder2";  //add red borders-and text
                        document.getElementById("invalid-month").innerHTML = "Invalid Date";  
                        test= false;   
                    }  
                    if ((lyear===true) && (day>29))  
                    {  
                        document.getElementById("month").className="errorborder2";  //add red borders-and text
                        document.getElementById("day").className="errorborder2";  //add red borders-and text
                        document.getElementById("year").className="errorborder2";  //add red borders-and text
                        document.getElementById("invalid-month").innerHTML = "Invalid Date";  
                        test= false;  
                    }  
                }  
            }  
            else  
            {  
                document.getElementById("month").className="errorborder2";  //add red borders-and text
                document.getElementById("day").className="errorborder2";  //add red borders-and text
                document.getElementById("year").className="errorborder2";  //add red borders-and text
                document.getElementById("invalid-month").innerHTML = "Enter Date in proper mm/dd/yyyy";  
                test= false;  
            }   
        }
    //*****Email **************//
    
      var email = document.getElementById("email").value;
      var emailpat = /^(([a-zA-Z]|[0-9])|([-]|[_]|[.]))+[@](([a-zA-Z0-9])|([-])){2,63}[.](([a-zA-Z0-9]){2,63})+$/;
     if (email === "" || email.length === 0) //checks if empty
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        event.preventDefault();  
        test= false;
    }
    else
    {
        document.getElementById("email").className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-email").innerHTML = "";
        document.getElementById("label-email").style.color = "#000";
    }
    
    if(!email.match(emailpat))
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        document.getElementById("invalid-email").innerHTML = "Please enter valid email (example@example.com/ca)";
        event.preventDefault();  
        test= false;
    }
    if(email.length>256)
    {
        document.getElementById("email").className="errorBorderLong";  //add red borders-and text
        document.getElementById("label-email").style.color = "red";
        document.getElementById("invalid-email").innerHTML = "Email address is too long)";
        event.preventDefault();  
        test= false;
    }
    
    //*****Country **************//
    var country = document.getElementById("country").value;
     if (country === "00" || country==="") //checks if empty
    {
        document.getElementById("country").className="errorborder2";  //add red borders-and text
        document.getElementById("invalid-country").innerHTML = "Please enter your country";
        event.preventDefault();  
        test=false;
    }
    //*****Reigon **************//
     var reigon = document.getElementById("reigon").value;
     if (reigon === "00"||reigon==="") //checks if empty
    {
        document.getElementById("reigon").className="errorborder2";  //add red borders-and text
        document.getElementById("invalid-reigon").innerHTML = "Please enter your reigon";
        event.preventDefault();  
        test=false;
    }
    //*****City **************//
    var city = document.getElementById("city").value;
     if (city === "00"||city===""||city.length===0) //checks if empty
    {
        document.getElementById("city").className="errorborder2";  //add red borders-and text
        document.getElementById("invalid-city").innerHTML = "Please enter your city";
        event.preventDefault();  
        test=false;
    }
    if(city.length>60)
    {
       document.getElementById("city").className="errorborder2";  //add red borders-and text
        document.getElementById("invalid-city").innerHTML = "City name is too long";
        event.preventDefault();  
        test=false; 
    }
 
    //*****Passwords  **************//
    
      var password = document.getElementById("password").value;
      if (password === "" || password.length === 0) //checks if empty
        {
            document.getElementById("password").className="errorBorder";  //add red borders-and text
            document.getElementById("invalid-password").innerHTML = "Please enter your password";
            event.preventDefault();  
            test=false;
        }
      
      var password2 = document.getElementById("passwordRepeat").value;
      if (password2 === "" || password2.length === 0) //checks if empty
        {
            document.getElementById("passwordRepeat").className="errorBorder";  //add red borders-and text
            document.getElementById("invalid-passwordRepeat").innerHTML = "Please Re-enter your password";
            event.preventDefault();  
            test=false;
        }
    
       if(password !== password2)
       {
            document.getElementById("password").className="errorBorder";  //add red borders-and text
            document.getElementById("invalid-password").innerHTML = "Passwords Do Not Match";
            event.preventDefault();  
            test=false;
       }
       else
       {
           if(password.length >=96)
            {
                document.getElementById("password").className="errorBorder";  //add red borders-and text
                document.getElementById("invalid-password").innerHTML = "Max Length Has Been Reached";
                event.preventDefault();  
                test=false;
            }
            else
            {
                var score = scorePassword(password);
                if(score<60)
                {
                    document.getElementById("password").className="errorBorder";  //add red borders-and text
                    document.getElementById("invalid-password").innerHTML = "Password is not Strong Enough";
                    event.preventDefault();  
                    test=false;
                }
            }  
       }
}

function validateFirstName(event)
{
    var form = event.currentTarget.id;
    var name = "invalid-"+form;
    var label= "label-"+form;
    var first = event.currentTarget.value;
     if (first === "" || first.length === 0) //checks if empty
    {
        event.currentTarget.className="errorBorder";  //add red borders-and text
        document.getElementById(label).style.color = "red";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";    
        document.getElementById(label).style.color = "#000";
    }
}
function validateLastName(event) //Level One
{
    var form = event.currentTarget.id;
    var name = "invalid-"+form;
    var label= "label-"+form;
    alert(label);
    var last = event.currentTarget.value;
     if (last === "" || last.length === 0) //checks if empty
    {
        event.currentTarget.className="errorBorder";  //add red borders-and text
        document.getElementById(label).style.color = "red";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";
        document.getElementById(label).style.color = "#000";
    }
}

function validateMonth(event) //Level One
{
     var form = event.currentTarget.id;
     var name = "invalid-"+form.name;
     var label= "label-"+form;
     var month = event.currentTarget.value;
     if (month === "00") //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById(name).innerHTML = "Please enter your birth month";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";    
    }
}

function validateDay(event) //Level One
{
     var form = this;
     var name = "invalid-"+form.name;
     var day = event.currentTarget.value;
     if (day === "00") //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById(name).innerHTML = "Please enter your birth month";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";    
    }
}
function validateYear(event) //Level One
{
     var form = this;
     var name = "invalid-"+form.name;
     var year = event.currentTarget.value;
     if (year === "00") //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById(name).innerHTML = "Please enter your birth year";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";    
    }
}

function validateEmail(event) //Level One
{
    var email = event.currentTarget.value;
    var label= "label-"+event.currentTarget.id;
     if (email === "" || email.length === 0) //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById(label).style.color = "red";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-email").innerHTML = "";
        document.getElementById(label).style.color = "#000";
    }
}

function validateCountry(event) //Level One
{
     var form = this;
     var name= "invalid-"+form.name;
     var country = event.currentTarget.value;
     var select = document.getElementById("reigon");
     var i;
     var city_stateArr;
    
     if (country === "00") //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById(name).innerHTML = "Please enter your country";
        event.preventDefault();  
    }
    else 
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById(name).innerHTML = "";  
        
    }
}

function validateReigon(event) //Level One
{
    var reigon = event.currentTarget.value;
     if (reigon === "" || reigon.length === 0 || reigon === "00") //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById("invalid-reigon").innerHTML = "Please enter your reigon";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-reigon").innerHTML = ""; 
         for(i=select.options.length-1;i>=0;i--)
        {
        select.remove(i);
        }
        select.options[select.options.length] = new Option("City", "00");
       city_stateArr = city_states[country].split("|");
        
       for (var i = 1; i <= city_stateArr.length; i++)
        {
            if(city_stateArr[i] !== "" || city_stateArr[i].length != 00)
            {
			     select.options[i] = new Option(city_stateArr[i],city_stateArr[i]);
            }
        }
        document.getElementById("city").addEventListener("blur", validateReigon);
    }
}


function validateCity(event) //Level One
{
    var city = event.currentTarget.value;
     if (city === "" || city.length === 0) //checks if empty
    {
        event.currentTarget.className="errorBorderLong";  //add red borders-and text
        document.getElementById("invalid-city").innerHTML = "Please enter your city";
        event.preventDefault();  
    }
    else
    {
        event.currentTarget.className =("sminputs");  //if fixed applies old style
        document.getElementById("invalid-city").innerHTML = "";    
    }
}

function scorePassword(pass) 
{
    var score = 0;
    if (!pass)
        return score;

    // award every unique letter until 5 repetitions
    var letters = new Object();
    for (var i=0; i<pass.length; i++) 
    {
        letters[pass[i]] = (letters[pass[i]] || 0) + 1;
        score += 5.0 / letters[pass[i]];
    }

    // bonus points for mixing it up
    var variations = 
    {
        digits: /\d/.test(pass),
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        nonWords: /\W/.test(pass),
    }

    variationCount = 0;
    for (var check in variations) 
    {
        variationCount += (variations[check] == true) ? 1 : 0;
    }
    score += (variationCount - 1) * 10;

    return parseInt(score);
}

function passwordStrength(event) 
{
    var current = event.currentTarget.value;
    var score = scorePassword(current);
    var warning = document.getElementById("passwordstrength");
   
    if (score >= 100)
    {
        warning.className = "veryGood";
        warning.innerHTML ="";
        warning.innerHTML ="Very Strong";
        
    }
    else if (score >= 80)
    {
        warning.className = "veryGood";
        warning.innerHTML ="";
        warning.innerHTML ="Strong";
    }
    else if (score >= 60)
    {
        warning.className = "good";
        warning.innerHTML ="";
        warning.innerHTML ="Good";
    }
    else if (score >= 30)
    {
        warning.className = "weak";
        warning.innerHTML ="";
        warning.innerHTML ="Weak";
    }
    else if (score < 30)
    {
        warning.className = "weak";
        warning.innerHTML ="";
        warning.innerHTML ="Very Weak";
    }
    return "";
}
